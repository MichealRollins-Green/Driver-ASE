#!/usr/bin/perl -w

use FindBin qw($Bin);
use lib "$Bin/..";
use Parsing_Routines;
use WGS_Analysis;
use Cwd "realpath";
use Getopt::Long;
use MCE::Map;
use strict;

my $time = localtime;
print "Script started on $time.\n";

#Changes to the directory of the script executing;
chdir $Bin;

my $parsing = TCGA_Lib::Parsing_Routines->new;
my $wgs_analysis = TCGA_Lib::WGS_Analysis->new;
my $TCGA_Pipeline_Dir = realpath("../../");
my $Analysispath = realpath("../../Analysis");

GetOptions(
    'disease|d=s' => \my $disease_abbr,#e.g. OV
    'table_file|f=s' => \my $file,
    'output|o=s' => \my $annotate_vars,
    'help|h' => \my $help
) or die "Incorrect options!\n",$parsing->usage;

if($help)
{
    $parsing->usage("4.1");
}

if(!defined $disease_abbr || !defined $file)
{
    print "disease type and/or the table file was not entered!\n";
    $parsing->usage("4.1");
}

my $WGS_Path = "$Analysispath/$disease_abbr/WGS_Analysis";

if(!defined $annotate_vars)
{
    $annotate_vars = "annotate_vars";
    print STDERR "using $annotate_vars as default\n";
}

`mkdir -p "$WGS_Path"` unless(-d "$WGS_Path");
chdir "$WGS_Path";

`mkdir -p $WGS_Path/$annotate_vars` unless(-d "$WGS_Path/$annotate_vars");

#mk_files_for_wgs(somatic_variants directory,output file)
$wgs_analysis->mk_files_for_wgs("$WGS_Path/somatic_variants","$WGS_Path/ff");

$parsing->matricize("$WGS_Path/ff","$WGS_Path/ff",1,6,"$WGS_Path");

`tar zcvf mutations.tgz matrix.tab rowlabels.txt collabels.txt`;
mkdir "$Analysispath/$disease_abbr/$disease_abbr\_finished_analysis_WGS" unless(-d "$disease_abbr\_finished_analysis_WGS");
`mv $WGS_Path/mutations.tgz $Analysispath/$disease_abbr/$disease_abbr\_finished_analysis_WGS`;

#var_ID_to_bed(rowlabels.txt file created from matricize,output file)
$wgs_analysis->var_ID_to_bed("$WGS_Path/rowlabels.txt","$WGS_Path/$annotate_vars/vars.bed");

chdir "$WGS_Path/$annotate_vars";
mkdir "$WGS_Path/$annotate_vars/overlap";
opendir(DD,"$TCGA_Pipeline_Dir/Database/reg") or die "Can't open $TCGA_Pipeline_Dir/Database/reg: $!\n";
my @zcat = readdir(DD);
@zcat = grep{!/\.$/}@zcat;
my $bed;
mce_map
{
    $bed = "$_";
    $bed =~ s/\.gz//;
    #simpl(files from the reg directory in the Database directory,output file)
    $wgs_analysis->simpl("zcat $TCGA_Pipeline_Dir/Database/reg/$_ |","$WGS_Path/$annotate_vars/overlap/$bed");
}@zcat;

#up_down_tss(the refseq.ucsc.ensembl.mrna.hg9.nr.bed file from the Database directory,upstream_of_tss_len,downstream_of_tss_len,output file)
$wgs_analysis->up_down_tss("$TCGA_Pipeline_Dir/Database/refseq.ucsc.ensembl.mrna.hg9.nr.bed",100,100,"$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_100");
#print1(output file created from up_down_tss,output file directed to the overlap directory)
$wgs_analysis->print_1("$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_100","$WGS_Path/$annotate_vars/overlap/100.100.bed");

$wgs_analysis->up_down_tss("$TCGA_Pipeline_Dir/Database/refseq.ucsc.ensembl.mrna.hg9.nr.bed",500,500,"$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_500");
$wgs_analysis->print_1("$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_500","$WGS_Path/$annotate_vars/overlap/500.500.bed");

$wgs_analysis->up_down_tss("$TCGA_Pipeline_Dir/Database/refseq.ucsc.ensembl.mrna.hg9.nr.bed",1000,1000,"$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_1kb");
$wgs_analysis->print_1("$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_1kb","$WGS_Path/$annotate_vars/overlap/1kb.1kb.bed");

$wgs_analysis->up_down_tss("$TCGA_Pipeline_Dir/Database/refseq.ucsc.ensembl.mrna.hg9.nr.bed",5000,1000,"$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_5kb");
$wgs_analysis->print_1("$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_5kb","$WGS_Path/$annotate_vars/overlap/5kb.1kb.bed");

$wgs_analysis->up_down_tss("$TCGA_Pipeline_Dir/Database/refseq.ucsc.ensembl.mrna.hg9.nr.bed",10000,10000,"$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_10kb");
$wgs_analysis->print_1("$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_10kb","$WGS_Path/$annotate_vars/overlap/10kb.1kb.bed");

$wgs_analysis->up_down_tss("$TCGA_Pipeline_Dir/Database/refseq.ucsc.ensembl.mrna.hg9.nr.bed",50000,1000,"$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_50kb");
$wgs_analysis->print_1("$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_50kb","$WGS_Path/$annotate_vars/overlap/50kb.1kb.bed");

$wgs_analysis->up_tss_gene("$TCGA_Pipeline_Dir/Database/refseq.ucsc.ensembl.mrna.hg9.nr.bed",10000,"$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_10000");
$wgs_analysis->print_1("$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_10000","$WGS_Path/$annotate_vars/overlap/10kb.gene.bed");

$parsing->pull_column("$WGS_Path/$annotate_vars/vars.bed",4,"$WGS_Path/$annotate_vars/tt1");

#vlookem_all(input files from the overlap directory,vars.bed file,path to the user defined directory from command line or default)
$wgs_analysis->vlookem_all("$WGS_Path/$annotate_vars/overlap","$WGS_Path/$annotate_vars/vars.bed","$WGS_Path/$annotate_vars");

opendir(DD,"$WGS_Path/$annotate_vars") or die "Can't open $WGS_Path/$annotate_vars: $!\n";
my @dd = readdir(DD);
@dd = grep{/^tt*/}@dd;
my $tt_num;
my $highest_tt = 0;
my @a;
for(my $i = 0;$i < scalar(@dd);$i++)
{
    @a = unpack("(a2)*",$dd[$i]);
    $tt_num = $a[1];
    if($highest_tt < $tt_num)
    { 
        $highest_tt = $tt_num;
    }
}

my $tt = $a[0] . $highest_tt;

$parsing->pull_column("$WGS_Path/$annotate_vars/$tt",1,"$WGS_Path/$annotate_vars/rowlabels.txt");
$parsing->pull_column("$WGS_Path/$annotate_vars/$tt","2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19","$WGS_Path/$annotate_vars/matrix.tab");

#my_up_down_tss(refseq.ucsc.ensembl.mrna.hg9.nr.bed file from the Database directory,upstream_of_tss_len,downstream_of_tss_len,output file)
$wgs_analysis->my_up_down_tss("$TCGA_Pipeline_Dir/Database/refseq.ucsc.ensembl.mrna.hg9.nr.bed",10000,0,"$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_10000_0_pull");
$parsing->pull_column("$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_10000_0_pull","1,2,3,4","$WGS_Path/$annotate_vars/mrna.hg9.nr.bed_10000_0_sort");
`sort -k 1,1 -k 2,2n $WGS_Path/$annotate_vars/mrna.hg9.nr.bed_10000_0_sort > $WGS_Path/$annotate_vars/gene.bed`;
`overlapSelect $WGS_Path/$annotate_vars/vars.bed $WGS_Path/$annotate_vars/gene.bed -idOutput $WGS_Path/$annotate_vars/out`;

$parsing->strip_head("$WGS_Path/$annotate_vars/out","$WGS_Path/$annotate_vars/out_pull");
$parsing->pull_column("$WGS_Path/$annotate_vars/out_pull","2,1","$WGS_Path/$annotate_vars/out_sort");
`sort -k 1,1 $WGS_Path/$annotate_vars/out_sort > $WGS_Path/$annotate_vars/var2gene.tab`;

#mk_coding(vars.bed file,output file)
$wgs_analysis->mk_coding("$WGS_Path/$annotate_vars/vars.bed","$WGS_Path/$annotate_vars/vars_grep");
`cat $WGS_Path/$annotate_vars/vars_grep | grep shift > $WGS_Path/$annotate_vars/vars_sort.txt`;
`sort -k 1,1 -k 2,2n $WGS_Path/$annotate_vars/vars_sort.txt > $WGS_Path/$annotate_vars/shifts.bed`;
$wgs_analysis->mk_coding("$WGS_Path/$annotate_vars/vars.bed","$WGS_Path/$annotate_vars/vars_grep");
`cat $WGS_Path/$annotate_vars/vars_grep | grep -v shift > $WGS_Path/$annotate_vars/vars_sort.txt`;
`sort -k 1,1 -k 2,2n $WGS_Path/$annotate_vars/vars_sort.txt > $WGS_Path/$annotate_vars/subs.bed`;

#Syn(subs.ved file,genome,output file,path to the Database directory)
$wgs_analysis->Syn("$WGS_Path/$annotate_vars/subs.bed","hg19","$WGS_Path/$annotate_vars/subs.syn","$TCGA_Pipeline_Dir/Database");
#mk_uniq_label(output file from Syn,output file)
$wgs_analysis->mk_uniq_label("$WGS_Path/$annotate_vars/subs.syn","$WGS_Path/$annotate_vars/subs.syn_sort");
`sort -k 1,1 -k 12,12n $WGS_Path/$annotate_vars/subs.syn_sort > $WGS_Path/$annotate_vars/subs.syn_sort2`;
`sort -k 1,1 -u $WGS_Path/$annotate_vars/subs.syn_sort2 > $WGS_Path/$annotate_vars/subs.syn2`;

$parsing->pull_column("$WGS_Path/$annotate_vars/subs.syn2","2,3,4,5,6,7,8,9,10,11,12,13,14","$WGS_Path/$annotate_vars/subs.syn2_process");

#process_syn(output file from pull_column,output file)
$wgs_analysis->process_syn("$WGS_Path/$annotate_vars/subs.syn2_process","$WGS_Path/$annotate_vars/t1");

`overlapSelect $TCGA_Pipeline_Dir/Database/ccds.hg19.bed $WGS_Path/$annotate_vars/shifts.bed $WGS_Path/$annotate_vars/o`;

#process_shifts(output file from overlapSelect,output file)
$wgs_analysis->process_shifts("$WGS_Path/$annotate_vars/o","$WGS_Path/$annotate_vars/t1");

#pt(the rowlabels.txt file created from matricize in script 4.1,output file)
$wgs_analysis->pt("$WGS_Path/rowlabels.txt","$WGS_Path/$annotate_vars/t2");

$parsing->vlookup("$WGS_Path/$annotate_vars/t2",1,"$WGS_Path/$annotate_vars/t1",1,"2,3","y","$WGS_Path/$annotate_vars/syn_pull");

$parsing->pull_column("$WGS_Path/$annotate_vars/syn_pull","2,3,4","$WGS_Path/$annotate_vars/syn.tab");

`tar zcvf annotations.tgz matrix.tab rowlabels.txt collabels.txt syn.tab`;
mkdir "$Analysispath/$disease_abbr/$disease_abbr\_finished_analysis_WGS" unless(-d "$Analysispath/$disease_abbr/$disease_abbr\_finished_analysis_WGS");
`mv $WGS_Path/$annotate_vars/annotations.tgz $Analysispath/$disease_abbr/$disease_abbr\_finished_analysis_WGS`;

`overlapSelect $TCGA_Pipeline_Dir/Database/ccds.hg19.bed $WGS_Path/$annotate_vars/vars.bed $WGS_Path/$annotate_vars/o.bed`;
`overlapSelect $WGS_Path/$annotate_vars/o.bed $TCGA_Pipeline_Dir/Database/refseq.ucsc.ensembl.mrna.hg9.nr.bed -idOutput $WGS_Path/$annotate_vars/out`;

$parsing->strip_head("$WGS_Path/$annotate_vars/out","$WGS_Path/$annotate_vars/out_pull");
$parsing->pull_column("$WGS_Path/$annotate_vars/out_pull","2,1","$WGS_Path/$annotate_vars/var2gene.coding.tab");

$parsing->pull_column("$Analysispath/$disease_abbr/$disease_abbr\_tables/$file","1,7","$WGS_Path/$annotate_vars/look.tab");

#two files: mut_ase_look.txt and coding_genes.tab are pre-created
`cp $TCGA_Pipeline_Dir/Database/mut_ase_look.txt $WGS_Path/$annotate_vars`;
`cp $TCGA_Pipeline_Dir/Database/coding_genes.tab $WGS_Path/$annotate_vars`;
`tar zcvf somatic_calls.tgz look.tab var2gene.tab var2gene.coding.tab coding_genes.tab mut_ase_look.txt`;
`mv $WGS_Path/$annotate_vars/somatic_calls.tgz $Analysispath/$disease_abbr/$disease_abbr\_finished_analysis_WGS`;

chdir "$WGS_Path";
my @del_files = $parsing->get_only_files_in_dir("$WGS_Path");
#Removes all files after the processes have finished.
for(my $i = 0;$i < scalar(@del_files);$i++)
{
    `rm "$del_files[$i]"`;
}
undef @del_files;
chdir "$WGS_Path/$annotate_vars";
@del_files = $parsing->get_only_files_in_dir("$WGS_Path/$annotate_vars");
for(my $i = 0;$i < scalar(@del_files);$i++)
{
    `rm "$del_files[$i]"`;
}

print "All jobs have finished for $disease_abbr.\n";

$time = localtime;
print "Script finished on $time.\n";

exit;